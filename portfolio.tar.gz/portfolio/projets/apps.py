from django.apps import AppConfig


class ProjetsConfig(AppConfig):
    name = 'projets'

